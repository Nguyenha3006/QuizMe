"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Clock, Flame, TrendingUp, Flag, ChevronLeft, ChevronRight, X } from "lucide-react"

type ExamScreen = "list" | "confirmation" | "exam"

export default function ExamInterface() {
  const [screen, setScreen] = useState<ExamScreen>("list")
  const [selectedExam, setSelectedExam] = useState<any>(null)
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [timeLeft, setTimeLeft] = useState(5400) // 90 minutes
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [flaggedQuestions, setFlaggedQuestions] = useState<Set<number>>(new Set())

  const exams = [
    {
      id: 1,
      title: "ĐỀ THI TỐT NGHIỆP THPT 2024",
      code: "101",
      source: "Bộ GD&ĐT",
      difficulty: "4/5",
      attempts: "17,842",
      avgScore: "7.8",
      duration: 90,
      questions: 50,
      isPinned: true,
    },
    {
      id: 2,
      title: "ĐỀ THI THỬ CHUYÊN KHTN 2024",
      code: "102",
      source: "Trường THPT Chuyên KHTN",
      difficulty: "5/5",
      attempts: "12,450",
      avgScore: "7.2",
      duration: 90,
      questions: 50,
      isPinned: true,
    },
    {
      id: 3,
      title: "ĐỀ THI THỬ CHUYÊN NGUYỄN HUỆ 2024",
      code: "103",
      source: "Trường THPT Chuyên Nguyễn Huệ",
      difficulty: "4/5",
      attempts: "9,320",
      avgScore: "7.5",
      duration: 90,
      questions: 50,
      isPinned: false,
    },
  ]

  const questions = [
    {
      id: 1,
      text: "Cho hàm số $f(x) = x^3 - 3x^2 + 2$. Tìm giá trị cực đại của hàm số.",
      options: ["A. 2", "B. 1", "C. 0", "D. -1"],
      correctAnswer: "A",
      image: null,
    },
    {
      id: 2,
      text: "Tính tích phân $\\int_0^1 (2x + 1) dx$",
      options: ["A. 1", "B. 2", "C. 3", "D. 4"],
      correctAnswer: "B",
      image: null,
    },
    // Add more questions as needed
    ...Array.from({ length: 48 }, (_, i) => ({
      id: i + 3,
      text: `Câu hỏi ${i + 3}: Đây là một câu hỏi mẫu về Toán học.`,
      options: ["A. Đáp án A", "B. Đáp án B", "C. Đáp án C", "D. Đáp án D"],
      correctAnswer: "A",
      image: null,
    })),
  ]

  const handleStartExam = (exam: any) => {
    setSelectedExam(exam)
    setScreen("confirmation")
  }

  const handleConfirmExam = () => {
    setScreen("exam")
    setTimeLeft(selectedExam.duration * 60)
  }

  const handleAnswerQuestion = (option: string) => {
    setAnswers({ ...answers, [currentQuestion]: option })
  }

  const toggleFlagQuestion = (questionId: number) => {
    const newFlagged = new Set(flaggedQuestions)
    if (newFlagged.has(questionId)) {
      newFlagged.delete(questionId)
    } else {
      newFlagged.add(questionId)
    }
    setFlaggedQuestions(newFlagged)
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const getTimeColor = () => {
    if (timeLeft <= 300) return "#DC3545" // Red
    if (timeLeft <= 600) return "#FFC107" // Yellow
    return "#CCD6F6" // Off-white
  }

  // Screen 1: Exam List
  if (screen === "list") {
    return (
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="mb-12">
          <h2 className="text-5xl font-bold mb-4" style={{ color: "#64FFDA" }}>
            TRẠM CHỌN NHIỆM VỤ
          </h2>
          <p className="text-lg" style={{ color: "#CCD6F6" }}>
            Chọn đề thi để bắt đầu luyện tập
          </p>
        </div>

        <div className="space-y-4">
          {exams.map((exam) => (
            <Card
              key={exam.id}
              className="border-2 hover:shadow-lg transition-all cursor-pointer"
              style={{
                backgroundColor: "#112240",
                borderColor: "#64FFDA",
              }}
              onClick={() => handleStartExam(exam)}
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-xl font-bold" style={{ color: "#CCD6F6" }}>
                        {exam.title}
                      </h3>
                      {exam.isPinned && <Badge style={{ backgroundColor: "#64FFDA", color: "#0A192F" }}>📌 Ghim</Badge>}
                    </div>
                    <p className="text-sm" style={{ color: "#CCD6F6" }}>
                      Mã đề {exam.code} | Nguồn: {exam.source}
                    </p>
                  </div>

                  <div className="flex items-center gap-6 mr-6">
                    <div className="text-center">
                      <div className="flex items-center gap-1 mb-1" style={{ color: "#FFC107" }}>
                        <Flame className="w-4 h-4" />
                        <span className="text-sm font-semibold">Độ khó</span>
                      </div>
                      <p className="font-bold" style={{ color: "#CCD6F6" }}>
                        {exam.difficulty}
                      </p>
                    </div>

                    <div className="text-center">
                      <div className="flex items-center gap-1 mb-1" style={{ color: "#3399FF" }}>
                        <TrendingUp className="w-4 h-4" />
                        <span className="text-sm font-semibold">Lượt thi</span>
                      </div>
                      <p className="font-bold" style={{ color: "#CCD6F6" }}>
                        {exam.attempts}
                      </p>
                    </div>

                    <div className="text-center">
                      <div className="flex items-center gap-1 mb-1" style={{ color: "#28a745" }}>
                        <TrendingUp className="w-4 h-4" />
                        <span className="text-sm font-semibold">Điểm TB</span>
                      </div>
                      <p className="font-bold" style={{ color: "#CCD6F6" }}>
                        {exam.avgScore}
                      </p>
                    </div>
                  </div>

                  <Button
                    style={{
                      backgroundColor: "#64FFDA",
                      color: "#0A192F",
                    }}
                    className="font-bold hover:opacity-90"
                  >
                    VÀO PHÒNG THI
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  // Screen 2: Confirmation
  if (screen === "confirmation") {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
        <Card
          className="w-full max-w-md border-2"
          style={{
            backgroundColor: "#112240",
            borderColor: "#64FFDA",
          }}
        >
          <CardHeader>
            <CardTitle style={{ color: "#64FFDA" }}>XÁC NHẬN VÀO PHÒNG THI</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <p className="text-sm mb-2" style={{ color: "#CCD6F6" }}>
                Đề thi:
              </p>
              <p className="font-bold text-lg" style={{ color: "#CCD6F6" }}>
                {selectedExam?.title} - Mã đề {selectedExam?.code}
              </p>
            </div>

            <div className="space-y-3 p-4 rounded-lg" style={{ backgroundColor: "#0A192F" }}>
              <div className="flex items-start gap-3">
                <Clock className="w-5 h-5 mt-1" style={{ color: "#FFC107" }} />
                <div>
                  <p className="font-semibold" style={{ color: "#CCD6F6" }}>
                    Thời gian làm bài: {selectedExam?.duration} phút
                  </p>
                  <p className="text-sm" style={{ color: "#CCD6F6" }}>
                    Đồng hồ sẽ bắt đầu ngay lập tức
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <X className="w-5 h-5 mt-1" style={{ color: "#DC3545" }} />
                <div>
                  <p className="font-semibold" style={{ color: "#CCD6F6" }}>
                    Không thể tạm dừng
                  </p>
                  <p className="text-sm" style={{ color: "#CCD6F6" }}>
                    Vui lòng đảm bảo bạn không bị làm phiền
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Badge style={{ backgroundColor: "#28a745", color: "white" }}>✓</Badge>
                <div>
                  <p className="font-semibold" style={{ color: "#CCD6F6" }}>
                    Bài làm sẽ tự động nộp
                  </p>
                  <p className="text-sm" style={{ color: "#CCD6F6" }}>
                    Khi hết giờ
                  </p>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setScreen("list")}
                className="flex-1"
                style={{ borderColor: "#64FFDA", color: "#64FFDA" }}
              >
                Để sau
              </Button>
              <Button
                onClick={handleConfirmExam}
                className="flex-1 font-bold"
                style={{
                  backgroundColor: "#64FFDA",
                  color: "#0A192F",
                }}
              >
                BẮT ĐẦU LÀM BÀI
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Screen 3: Exam Interface
  if (screen === "exam") {
    const question = questions[currentQuestion]
    const answered = Object.keys(answers).length
    const flagged = flaggedQuestions.size

    return (
      <div className="min-h-screen flex flex-col" style={{ backgroundColor: "#0A192F" }}>
        {/* Header */}
        <div
          className="border-b p-4 flex items-center justify-between"
          style={{ backgroundColor: "#112240", borderColor: "#1E3A5F" }}
        >
          <div style={{ color: "#CCD6F6" }}>
            <p className="text-sm">Nguyễn Thị Linh Chi | SBD: 01000071</p>
          </div>

          <div className="text-center">
            <div className="text-4xl font-bold font-mono" style={{ color: getTimeColor() }}>
              ⏳ {formatTime(timeLeft)}
            </div>
          </div>

          <div className="flex gap-2">
            <Button variant="outline" style={{ borderColor: "#DC3545", color: "#DC3545" }}>
              NỘP BÀI
            </Button>
            <Button variant="ghost" onClick={() => setScreen("list")} style={{ color: "#CCD6F6" }}>
              ✕
            </Button>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex flex-1 overflow-hidden">
          {/* Left Column - Question Display */}
          <div className="w-2/5 border-r p-6 overflow-y-auto" style={{ borderColor: "#1E3A5F" }}>
            <div className="mb-6">
              <h3 className="text-lg font-bold mb-4" style={{ color: "#64FFDA" }}>
                Câu {currentQuestion + 1}/{questions.length}
              </h3>
              <p className="text-base leading-relaxed mb-6" style={{ color: "#CCD6F6" }}>
                {question.text}
              </p>
            </div>
          </div>

          {/* Right Column - Answer Options */}
          <div className="w-3/5 p-6 overflow-y-auto">
            <div className="mb-8">
              <h4 className="text-sm font-semibold mb-4" style={{ color: "#64FFDA" }}>
                CHỌN ĐÁP ÁN
              </h4>
              <div className="space-y-3">
                {question.options.map((option, idx) => {
                  const optionKey = String.fromCharCode(65 + idx) // A, B, C, D
                  const isSelected = answers[currentQuestion] === optionKey
                  return (
                    <button
                      key={idx}
                      onClick={() => handleAnswerQuestion(optionKey)}
                      className="w-full p-4 rounded-lg border-2 text-left transition-all"
                      style={{
                        backgroundColor: isSelected ? "#3399FF" : "#112240",
                        borderColor: isSelected ? "#3399FF" : "#1E3A5F",
                        color: "#CCD6F6",
                      }}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className="w-6 h-6 rounded-full border-2 flex items-center justify-center"
                          style={{
                            borderColor: isSelected ? "#64FFDA" : "#1E3A5F",
                            backgroundColor: isSelected ? "#64FFDA" : "transparent",
                          }}
                        >
                          {isSelected && <span style={{ color: "#0A192F" }}>✓</span>}
                        </div>
                        <span>{option}</span>
                      </div>
                    </button>
                  )
                })}
              </div>
            </div>

            {/* Navigation */}
            <div className="flex gap-3 mt-8">
              <Button
                onClick={() => setCurrentQuestion(Math.max(0, currentQuestion - 1))}
                disabled={currentQuestion === 0}
                variant="outline"
                style={{ borderColor: "#64FFDA", color: "#64FFDA" }}
              >
                <ChevronLeft className="w-4 h-4 mr-2" />
                Câu trước
              </Button>
              <Button
                onClick={() => setCurrentQuestion(Math.min(questions.length - 1, currentQuestion + 1))}
                disabled={currentQuestion === questions.length - 1}
                style={{ backgroundColor: "#64FFDA", color: "#0A192F" }}
              >
                Câu sau
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
              <Button
                onClick={() => toggleFlagQuestion(currentQuestion)}
                variant="outline"
                style={{
                  borderColor: flaggedQuestions.has(currentQuestion) ? "#FFC107" : "#1E3A5F",
                  color: flaggedQuestions.has(currentQuestion) ? "#FFC107" : "#CCD6F6",
                }}
              >
                <Flag className="w-4 h-4 mr-2" fill={flaggedQuestions.has(currentQuestion) ? "currentColor" : "none"} />
                Đánh dấu
              </Button>
            </div>
          </div>
        </div>

        {/* Footer - Question Navigator */}
        <div className="border-t p-4 overflow-x-auto" style={{ backgroundColor: "#112240", borderColor: "#1E3A5F" }}>
          <div className="flex gap-2 justify-center flex-wrap">
            {questions.map((_, idx) => {
              const isAnswered = answers[idx]
              const isFlagged = flaggedQuestions.has(idx)
              const isCurrent = idx === currentQuestion

              return (
                <button
                  key={idx}
                  onClick={() => setCurrentQuestion(idx)}
                  className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all relative"
                  style={{
                    backgroundColor: isAnswered ? "#3399FF" : isCurrent ? "#112240" : "transparent",
                    borderWidth: "2px",
                    borderColor: isCurrent ? "#64FFDA" : isAnswered ? "#3399FF" : "#1E3A5F",
                    color: isAnswered ? "white" : "#CCD6F6",
                  }}
                >
                  {idx + 1}
                  {isFlagged && (
                    <Flag className="w-3 h-3 absolute -top-1 -right-1" style={{ color: "#FFC107" }} fill="#FFC107" />
                  )}
                </button>
              )
            })}
          </div>
          <div className="flex justify-center gap-6 mt-4 text-sm">
            <div>
              <span style={{ color: "#CCD6F6" }}>Đã trả lời: </span>
              <span style={{ color: "#3399FF", fontWeight: "bold" }}>{answered}</span>
            </div>
            <div>
              <span style={{ color: "#CCD6F6" }}>Đánh dấu: </span>
              <span style={{ color: "#FFC107", fontWeight: "bold" }}>{flagged}</span>
            </div>
            <div>
              <span style={{ color: "#CCD6F6" }}>Chưa trả lời: </span>
              <span style={{ color: "#DC3545", fontWeight: "bold" }}>{questions.length - answered}</span>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
